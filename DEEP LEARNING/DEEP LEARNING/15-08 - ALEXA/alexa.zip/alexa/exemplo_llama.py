import requests
import json

url = 'http://localhost:11434/api/generate'

pergunta = input("O que desesja saber? ")
print("Aguarde... carregando...")
input_json = {
    "model": "llama3.1",
    "prompt": "responda sucintamente em português em poucas palavras em um parágrafo "+pergunta
}
response = requests.post(url, json=input_json)
print(response.text) # Verifique o conteúdo de resposta

# Dividir a string em linhas
linhas = response.text.strip().split("\n")

# Lista para armazenar os valores de 'response'
valores_response = []
# Processar cada linha como um objeto JSON
for linha in linhas:
    # Carregar a linha como um dicionário Python
    obj = json.loads(linha)
    # Obter o valor da chave 'response'
    resposta = obj.get('response')
    # Adicionar a lista de valores de 'response'
    valores_response.append(resposta)
# Juntar os valores de 'response' em uma única string
nova_string = ''.join(valores_response)
# Exibir a nova string resultado
print(nova_string)

